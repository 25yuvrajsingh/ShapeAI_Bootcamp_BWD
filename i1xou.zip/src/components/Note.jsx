import React from "react";

function Note() {
  return (
    <div>
      <h1>JavaScript and React.js</h1>
      <p>
        This was an amazing bootcamp taken by Shaurya Sinha Sir .We covered
        everything from scratch including Javascript ,recat.js , HTML
      </p>
    </div>
  );
}

export default Note;
