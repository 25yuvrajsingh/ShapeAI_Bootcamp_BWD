import React from "react";

function List() {
  return ( 
  <ul className="list">
     <li>FEFAF</li>
     <li>RTVGWTBVRW</li>
    </ul>;
  );
}

export default List;

